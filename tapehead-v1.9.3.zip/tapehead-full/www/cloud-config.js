/* Tapehead Pro — cloud config (also embedded in index.html) */
window.TAPEHEAD_CLOUD = {
  enabled: true,
  allowLocalFallback: false,
  supabaseUrl: 'https://dswhlqropbraofcrsdcj.supabase.co',
  supabaseAnonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRzd2hscXJvcGJyYW9mY3JzZGNqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTAyNjk1NjcsImV4cCI6MjEwNTg0NTU2N30.Le4_PkJw0BkCQndBc2fFblcxl_iiEcVdtoYVAwXPuiI',
  currency: 'USD',
  provider: 'pesapal',
  payApiUrl: '',
  stripePaymentLink: '',
  paypalLink: '',
  aiEnabled: true,
  aiApiUrl: '/api/ai'
};
